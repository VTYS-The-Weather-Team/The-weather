document.addEventListener('DOMContentLoaded', () => {
    console.log('Hourly weather data page loaded.');
    // Additional JavaScript can be added here for interactivity.
});
